import { useState } from "react";
import TodoInput from "./components/TodoInput";
import TodoTable, { type Task } from "./components/TodoTable";

export default function App() {
  const [saisie, setSaisie] = useState<string>("");
  const [taches, setTaches] = useState<Task[]>([]);

  const ajouterTache = () => {
    if (saisie.trim() === "") return;
    setTaches([...taches, { id: Date.now(), texte: saisie }]);
    setSaisie("");
  };

  return (
    <div>
      <h1>To-Do List</h1>

      <TodoInput
        valeur={saisie}
        onChange={setSaisie}
        onAdd={ajouterTache}
      />

      <TodoTable tasks={taches} />
    </div>
  );
}
